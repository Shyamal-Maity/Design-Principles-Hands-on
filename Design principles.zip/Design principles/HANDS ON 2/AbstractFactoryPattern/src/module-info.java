module AbstractFactoryPattern {
}
package com.cognizant.AbstractClasses;

public abstract class Tire {

}

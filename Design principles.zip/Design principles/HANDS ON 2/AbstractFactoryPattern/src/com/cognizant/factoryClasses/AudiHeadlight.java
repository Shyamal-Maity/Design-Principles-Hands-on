package com.cognizant.factoryClasses;

import com.cognizant.AbstractClasses.Headlight;

public class AudiHeadlight extends Headlight {

}

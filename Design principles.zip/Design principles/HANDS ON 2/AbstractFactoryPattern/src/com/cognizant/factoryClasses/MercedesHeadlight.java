package com.cognizant.factoryClasses;

import com.cognizant.AbstractClasses.Headlight;

public class MercedesHeadlight extends Headlight {

}

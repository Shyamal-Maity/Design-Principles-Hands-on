package com.cognizant.factoryClasses;

import com.cognizant.AbstractClasses.Tire;

public class MercedesTire extends Tire {

}

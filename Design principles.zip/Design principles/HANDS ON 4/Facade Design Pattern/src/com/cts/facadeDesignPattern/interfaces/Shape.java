package com.cts.facadeDesignPattern.interfaces;

public interface Shape {
	public void draw();
}

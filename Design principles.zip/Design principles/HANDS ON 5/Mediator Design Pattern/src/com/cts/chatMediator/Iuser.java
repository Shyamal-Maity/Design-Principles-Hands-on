package com.cts.chatMediator;

public interface Iuser {
	

	public abstract void sendMessage(String message);
	public abstract void receiveMessage(String message);
}

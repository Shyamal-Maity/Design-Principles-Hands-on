package com.cts.chatMediator;

public interface IchatMediator {

	public abstract void addUser(Iuser user);
	public abstract void sendMessage(String message);
}

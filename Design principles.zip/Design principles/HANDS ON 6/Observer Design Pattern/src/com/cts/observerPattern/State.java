package com.cts.observerPattern;

public class State {

}

package com.cts.observerPattern;

public interface Observer {

	public void update(Message m);
}

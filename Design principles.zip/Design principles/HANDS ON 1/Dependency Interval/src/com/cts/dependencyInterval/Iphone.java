package com.cts.dependencyInterval;

public interface Iphone {
	public String getPhonePart1();

	public double getPart1Cost();
}

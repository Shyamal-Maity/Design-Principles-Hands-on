package com.cts.sampleApplication;

public interface IorderRepair {
	void processOrder(String modelName);

	void processPhoneRepair(String modelName);

	void processAccessoryRepair(String accessoryType);
}

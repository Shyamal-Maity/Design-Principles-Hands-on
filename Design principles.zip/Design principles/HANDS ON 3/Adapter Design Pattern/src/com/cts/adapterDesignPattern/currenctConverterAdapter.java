package com.cts.adapterDesignPattern;

public interface currenctConverterAdapter {

	//return the amount in EURO
	double getAmount();
}

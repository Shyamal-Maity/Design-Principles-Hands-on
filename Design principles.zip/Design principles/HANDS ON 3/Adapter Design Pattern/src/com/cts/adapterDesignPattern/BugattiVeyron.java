package com.cts.adapterDesignPattern;

public class BugattiVeyron implements Movable {

	@Override
	public double getSpeed() {
		return 268;
	}

}

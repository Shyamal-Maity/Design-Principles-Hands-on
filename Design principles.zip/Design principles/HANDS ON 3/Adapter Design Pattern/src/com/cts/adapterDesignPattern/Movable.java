package com.cts.adapterDesignPattern;

public interface Movable {
	//returns speed in MPH
	double getSpeed();
	
}

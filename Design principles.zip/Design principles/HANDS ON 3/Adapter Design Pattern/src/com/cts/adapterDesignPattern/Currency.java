package com.cts.adapterDesignPattern;

public class Currency implements currencyConverter {

	public double getAmount() {
		return 100;
	}
}

package com.cts.adapterDesignPattern;

public interface currencyConverter {

	//returns amount in USD
	double getAmount();
	
}

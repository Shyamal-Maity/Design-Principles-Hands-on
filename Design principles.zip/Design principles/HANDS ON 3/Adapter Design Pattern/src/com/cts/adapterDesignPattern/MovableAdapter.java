package com.cts.adapterDesignPattern;

public interface MovableAdapter {
	
	//returns speed in KM/H
	double getSpeed();

}

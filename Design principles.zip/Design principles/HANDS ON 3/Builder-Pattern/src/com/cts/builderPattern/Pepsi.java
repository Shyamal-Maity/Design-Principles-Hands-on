package com.cts.builderPattern;

public class Pepsi extends ColdDrink {

	@Override
	public String name() {
		return "Pepse";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 40.f;
	}

}

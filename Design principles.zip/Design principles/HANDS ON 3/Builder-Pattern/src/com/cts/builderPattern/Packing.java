package com.cts.builderPattern;

public interface Packing {
	public String pack();
}

package com.cts.builderPattern;

public class Wrapper implements Packing {

	@Override
	public String pack() {
		return "Wraper";
	}

}

package com.cts.builderPattern;

public interface Item {

	public Packing packing();
	public float price();
	public String name();
	
	
	
}
